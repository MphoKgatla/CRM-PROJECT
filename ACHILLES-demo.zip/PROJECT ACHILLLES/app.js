/* ACHILLES: shared behaviour for the CRM screens.
   Everything here is front-end only. Real permissions must be enforced on the server. */
(function () {
    "use strict";

    /* ---------- Role (demo switch) ----------
       Open any page with ?role=sales or ?role=manager to preview that role.
       Replace this with the role returned by your login once the backend exists. */
    var role = new URLSearchParams(location.search).get("role");
    try {
        if (role === "sales" || role === "manager") {
            localStorage.setItem("achilles-role", role);
        } else {
            role = localStorage.getItem("achilles-role");
        }
    } catch (e) { /* storage blocked: fall back to the default below */ }
    if (role !== "sales" && role !== "manager") role = "manager";

    document.body.dataset.role = role;
    var chip = document.getElementById("role-chip");
    if (chip) chip.textContent = role === "manager" ? "Manager" : "Sales";

    // Manager-only pages: show a notice to Sales users instead of the page.
    if (document.body.dataset.require === "manager" && role !== "manager") {
        var main = document.getElementById("main");
        if (main) {
            main.innerHTML =
                '<div class="notice"><h1>Managers only</h1>' +
                "<p>Your role does not have access to this screen.</p>" +
                '<a class="button" href="Dashboard.html">Back to dashboard</a></div>';
        }
    }

    /* ---------- Mobile menu ---------- */
    var toggle = document.querySelector(".menu-toggle");
    var nav = document.getElementById("site-nav");
    if (toggle && nav) {
        toggle.addEventListener("click", function () {
            var open = nav.classList.toggle("is-open");
            toggle.setAttribute("aria-expanded", String(open));
        });
    }

    /* ---------- Tabs ---------- */
    document.querySelectorAll('[role="tablist"]').forEach(function (list) {
        var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));

        function select(tab, focus) {
            tabs.forEach(function (t) {
                var on = t === tab;
                t.setAttribute("aria-selected", String(on));
                t.tabIndex = on ? 0 : -1;
                var panel = document.getElementById(t.getAttribute("aria-controls"));
                if (panel) panel.hidden = !on;
            });
            if (focus) tab.focus();
        }

        tabs.forEach(function (tab, i) {
            tab.addEventListener("click", function () { select(tab, false); });
            tab.addEventListener("keydown", function (e) {
                var next = null;
                if (e.key === "ArrowRight") next = tabs[(i + 1) % tabs.length];
                if (e.key === "ArrowLeft") next = tabs[(i - 1 + tabs.length) % tabs.length];
                if (next) { e.preventDefault(); select(next, true); }
            });
        });
    });

    /* ---------- Form validation (forms marked data-validate) ---------- */
    document.querySelectorAll("form[data-validate]").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var first = null;

            form.querySelectorAll("[required]").forEach(function (control) {
                var field = control.closest(".field");
                var bad = !control.value.trim();
                if (field) field.classList.toggle("has-error", bad);
                if (bad && !first) first = control;
            });

            if (first) { first.focus(); return; }

            /* TODO: post the form to your backend here. */
            window.toast("Saved (demo). Connect your backend to store it.");
        });
    });

    /* ---------- Toast ---------- */
    var timer;
    window.toast = function (message) {
        var el = document.getElementById("toast");
        if (!el) {
            el = document.createElement("div");
            el.id = "toast";
            el.className = "toast";
            el.setAttribute("role", "status");
            el.setAttribute("aria-live", "polite");
            document.body.appendChild(el);
        }
        el.textContent = message;
        // restart the transition
        el.classList.remove("is-visible");
        void el.offsetWidth;
        el.classList.add("is-visible");
        clearTimeout(timer);
        timer = setTimeout(function () { el.classList.remove("is-visible"); }, 3800);
    };
})();
