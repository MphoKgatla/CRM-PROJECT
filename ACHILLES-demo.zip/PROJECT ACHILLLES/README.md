# ACHILLES CRM (front-end demo)

Static HTML/CSS/JS. No build step. Open `index.html` or host the folder as-is.

- Demo login: on `login.html` use "Enter as Manager" or "Enter as Sales" (or any credentials).
- Role preview: add `?role=sales` or `?role=manager` to any page.
- Backend (ASP.NET Core + database) is the next phase; forms are demo-only for now.

Host free: drag this folder onto https://app.netlify.com/drop
