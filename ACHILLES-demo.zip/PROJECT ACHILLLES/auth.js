/* ACHILLES: shared helpers for the account pages (login, register, reset, invite). */
(function () {
    "use strict";

    /* Show a message in a .status element. kind: "error" | "info" | "" */
    window.authStatus = function (el, message, kind) {
        if (!el) return;
        el.textContent = message;
        el.classList.remove("is-error", "is-info");
        if (kind === "error") el.classList.add("is-error");
        if (kind === "info") el.classList.add("is-info");
    };

    /* Returns a message if the password is too weak, otherwise "" */
    window.passwordProblem = function (pw) {
        if (!pw || pw.length < 8) return "The password needs 8 or more characters.";
        if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return "Use at least one letter and one number.";
        return "";
    };

    /* Show / Hide buttons for password fields */
    document.querySelectorAll(".pw-toggle").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var input = document.getElementById(btn.getAttribute("aria-controls"));
            if (!input) return;
            var show = input.type === "password";
            input.type = show ? "text" : "password";
            btn.textContent = show ? "Hide" : "Show";
            btn.setAttribute("aria-pressed", String(show));
        });
    });
})();
